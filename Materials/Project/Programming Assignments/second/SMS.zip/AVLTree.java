
public class AVLTree extends BST{
	Node root;

	public AVLTree() {
		super();
	}


	public Node insertNode(Node root, Student student) {
		/**
		 * insertNode inserts a student into a subtree whose root is "root" 
		 * input:	root - the root of the subtree
		 * 			x - the key to be inserted
		 * output: the (updated) root of the subtree
		 */
		// Note that the root here is a parameter, not the class member "root"

		root = super.insertNode(root, student);
		if(root!=null) {
			root.updateHeight();
			root = rebalance(root);
		}
		return root;
	}

	private Node rebalance(Node root) {
		// checks and re-balances a node if necessary
		// returns the (updated) root
		int lheight = Node.getHeight(root.getLeft());
		int rheight = Node.getHeight(root.getRight());
		if(Math.abs(lheight - rheight)<2)
			return root;
		Node heavyChild;
		if(lheight > rheight) {//root is left heavy
			heavyChild = root.getLeft();
			if(Node.getHeight(heavyChild.getLeft()) >= Node.getHeight(heavyChild.getRight())) { // left-left, case 1
				root = rightRotate(root);
			}
			else { // left-right, case 2
				root.setLeft(leftRotate(root.getLeft()));
				root = rightRotate(root);
			}
		}
		else {//root is right heavy
			heavyChild = root.getRight();
			if(Node.getHeight(heavyChild.getRight()) >= Node.getHeight(heavyChild.getLeft())) { // right_left, case 4
				root = leftRotate(root);
			}
			else { // right-left, case 3
				root.setRight(rightRotate(root.getRight()));
				root = leftRotate(root);
			}
		}
		return root;
	}
	
	private Node rightRotate(Node root) {
		Node k1 = root.getLeft();
		Node Y = k1.getRight();
		k1.setRight(root);
		root.setLeft(Y);
		root.updateHeight();
		k1.updateHeight();
		return k1;
	}
	private Node leftRotate(Node root) {
		Node k2 = root.getRight();
		Node Y = k2.getLeft();
		k2.setLeft(root);
		root.setRight(Y);
		root.updateHeight();
		k2.updateHeight();
		return k2;
	}
	public Node deleteNode(Node root, int x) {
		/**
		 * deleteNode deletes the node whose key is "x" from a subtree whose root is "root"
		 * input: 	root - the root of the subtree 
		 * 			x - the key of the node to be deleted
		 * output: the (updated) root of the subtree
		 */
		root = super.deleteNode(root, x);
		if(root!=null) {
			root.updateHeight();
			root = rebalance(root);
		}
		return root;
	}
}
