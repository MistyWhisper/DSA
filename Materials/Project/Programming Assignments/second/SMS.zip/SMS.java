import java.io.*;
import java.util.*;

public class SMS {
	private AVLTree tree;
	private static String msgNA = " is not found.";
	public SMS(String fileName) {
		tree = new AVLTree();
		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
		    String line;
		    while ((line = br.readLine()) != null)
		    	tree.insertNode(line);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public String query(int ID) {
		Node result = tree.findNode(ID);
		if(result == null)
			return ""+ ID + msgNA;
		return result.getData().getInfo();
	}
	public String unenroll(int ID) {
		Node result = tree.findNode(ID);
		if(result == null)
			return ""+ID+msgNA;
		Student student = result.getData();
		tree.deleteNode(student.getID());
		return student.getDeleteInfo();
	}
	public static void main(String[] args) {
		SMS sms = new SMS("studentList.txt");
		System.out.println("------------ EPU Student Management System ------------");
		while(true) {
			System.out.print("Input a command: ");
			Scanner sc= new Scanner(System.in);
			String line= sc.nextLine();   
			switch(line.charAt(0)) {
			case 'q':
				System.out.println(sms.query(Integer.parseInt(line.substring(1))));
				break;
			case 'u':
				System.out.println(sms.unenroll(Integer.parseInt(line.substring(1))));
				break;
			case 'e':
				System.out.println("Goodbye!");
				sc.close();
				return;
			}
		}
	}
}
