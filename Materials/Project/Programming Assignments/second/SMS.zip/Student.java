
public class Student {
	private String fName, sName;
	private char gender;
	private int ID, age;
	
	public Student (String line) {
		String fields[] = line.split(",");
		fName = fields[0];
		sName = fields[1];
		gender = fields[2].charAt(0);
		ID = Integer.valueOf(fields[3]);
		age = Integer.valueOf(fields[4]);
	}
	
	public int getID() {return ID;}
	
	public String getInfo() {
		return fName+" "+sName+" ("+ID+") is a "+(gender=='F'?"female":"male")+" student of age "+age+".";
	}
	
	public String getDeleteInfo() {
		return fName+" "+sName+" ("+ID+") is unenrolled from EPU.";
	}
}
