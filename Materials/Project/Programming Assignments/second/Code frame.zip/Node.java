/*Part 2*/
public class Node{
	/*Your code here.*/
	
}