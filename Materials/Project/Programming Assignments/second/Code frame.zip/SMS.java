/*Part 2*/
public class SMS{
	/*Your code here.*/
	
	public static void main(String[] args){
		/*Code of running the main procedure.*/
	}
}