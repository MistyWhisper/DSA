/*Part 2*/
public class Student{
	/*Your code here*/
	
}