/*Part 2*/
public class AVLTree extend BST{
	/*Your code here.*/
	
}