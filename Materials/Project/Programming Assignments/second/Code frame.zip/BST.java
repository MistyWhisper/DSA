/*Part 2*/
public class BST{
	/*Your code here.*/
	
}