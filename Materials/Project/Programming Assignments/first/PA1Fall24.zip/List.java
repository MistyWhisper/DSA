/*Add some comments by yourself.*/
class Node{
	private double x;
	private Node next;
	public Node(double x) {
		this.x = x;
		this.next = null;
	}
	public double getData() {
		return x;
	}
	public Node getNext() {
		return next;
	}
	public void setNext(Node next) {
		this.next = next;
	}
}
public class List {
	private Node head;
	public List() {
		this.head = null;
	}
	public boolean isEmpty() {
		return this.head == null;
	}
	public Node insertNode(int index, double x) {
		if(index < 0)
			return null;
		int currIndex = 1;
		Node currNode = this.head;
		while(currNode != null && index > currIndex) {
			currNode = currNode.getNext();
			currIndex ++;
		}		
		if(index > 0 && currNode == null)
			return null;
		
		Node newNode = new Node(x);
		if(index == 0) {
			newNode.setNext(this.head);
			this.head = newNode;
		}
		else {
			newNode.setNext(currNode.getNext());
			currNode.setNext(newNode);
		}
		return newNode;
	}
	public Node findNode(double x) {
		for(Node currNode = head; currNode != null; currNode = currNode.getNext())
			if(currNode.getData() == x)
				return currNode;
		return null;
	}
	public Node removeNode(double x) {
		if(head == null)
			return null;
		Node currNode = head;
		if(head.getData() == x) {
			this.head = head.getNext();
			return currNode;
		}
		for(; currNode.getNext() != null; currNode = currNode.getNext())
			if(currNode.getNext().getData() == x) {
				Node matchNode = currNode.getNext();
				currNode.setNext(matchNode.getNext());
				return matchNode;
			}
		return null;
	}
	public void displayList() {
		Node currNode = head;
		if(currNode != null) {
			System.out.print(currNode.getData());
			for(currNode = currNode.getNext(); currNode != null; currNode = currNode.getNext()) {
				System.out.print(" -> " + currNode.getData());
			}
		}
		else
			System.out.print("Empty List!");
		System.out.println();
	}
	public Node getLast() {
		if(this.head == null)
			return null;
		for(Node curr = this.head;; curr=curr.getNext())
			if(curr.getNext() == null)
				return curr;
	}
	public int removeRange(int start, int stop) {
		int count = 0, pos = 1;
		for(Node curr = this.head; curr!=null && pos<=stop; curr=curr.getNext()) {
			if(pos>=start) {
				count++;
				this.removeNode(curr.getData());
			}
			pos++;			
		}
		return count;
	}
	public static List makeList() {
		List l  = new List();
		l.insertNode(0, 3);
		l.insertNode(0, 4);
		l.insertNode(0, 2);
		l.insertNode(0, 8);
		l.insertNode(0, 1);
		return l;
	}
	public static void main(String[] args) {
		List l  = new List();
		System.out.println(l.getLast()==null);
		l = makeList();
		l.displayList();
		System.out.println(l.getLast().getData());
		System.out.println(l.removeRange(1, 3));
		l.displayList();
		l = makeList();
		System.out.println(l.removeRange(-3, 3));
		l.displayList();
		l = makeList();
		System.out.println(l.removeRange(5, 9));
		l.displayList();
		l = makeList();
		System.out.println(l.removeRange(6, 9));
		l.displayList();
		l = makeList();
		System.out.println(l.removeRange(-9, 9));
		l.displayList();
		l = makeList();
		System.out.println(l.removeRange(5, 2));
		l.displayList();
		l  = new List();
		System.out.println(l.removeRange(1, 4));
		l.displayList();
	}
};