/*Add some comments by yourself.*/
public class Stack {

	private char[] values;
	private int top;
	public Stack(int size) {
		this.values = new char[size];
		top = -1;
	}
	public boolean isEmpty() {
		return this.top < 0;
	}
	public boolean isFull() {
		return this.top == this.values.length - 1;
	}
	public char top() {
		if(top < 0)
			return Character.MAX_VALUE;
		return this.values[top];
	}
	public char push(char x) {
		if(isFull())
			return Character.MAX_VALUE;
		this.values[++top] = x;
		return top();
	}
	public char pop() {
		if(top < 0)
			return Character.MAX_VALUE;
		return this.values[top --];
	}
	public static boolean isOpen(char c) {
		String opens = "({[<";
		if(opens.indexOf(c)>=0)
			return true;
		return false;
	}
	public static boolean isMatch(char open, char close) {
		String opens = "({[<", closes = ")}]>";
		return opens.indexOf(open) == closes.indexOf(close);
	}
	public static boolean ValidBrackets(String str) {
		if(str == null)
			return false;
		Stack s = new Stack(str.length());
		for(int i=0; i<str.length(); i++) {
			char c = str.charAt(i);
			if(isOpen(c))
				s.push(c);
			else {
				if(!isMatch(s.pop(), c))
					return false;				
			}
		}
		return s.isEmpty();
	}
	public static void main(String[] args) {
		System.out.println(Stack.ValidBrackets("{()<()>}[]"));
		System.out.println(Stack.ValidBrackets("(<)>"));
		System.out.println(Stack.ValidBrackets("{()}["));
		System.out.println(Stack.ValidBrackets(""));
		System.out.println(Stack.ValidBrackets(null));
	}

}